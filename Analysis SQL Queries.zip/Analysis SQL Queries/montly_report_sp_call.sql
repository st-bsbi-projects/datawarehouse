call monthly_report('2022-01');



